JSBegin
=======

Support for the W3C JavaScript for beginners course.
